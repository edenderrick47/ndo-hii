<?php
		 define('MYSQL_DB_HOST', 'localhost');
		 define('MYSQL_DB_NAME', 'pvaluewriters');
		 define('MYSQL_DB_USERNAME', 'root');
		 define('MYSQL_DB_PASSWORD', '');
		 define('TABLE_PREFIX', '_');
		 define('SITE_LINK', '');
		 ?>