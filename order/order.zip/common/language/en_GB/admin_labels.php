<?php
define('LBL_MANDATORY','*');
//Register
define('LBL_FIRST_NAME','First name');
define('LBL_LAST_NAME','Last name');
define('LBL_EMAIL','Email address');
define('LBL_PASSWORD','Password');
define('LBL_DOB','Date of birth');
define('LBL_GENDER','Gender');
define('LBL_MOB','Mobile_number');
define('LBL_DESC','Description');
define('LBL_CNAME','Contact_name');
define('LBL_CEMAIL','Contact_email');
define('LBL_CPHONE','Contact phone');
define('LBL_CMOB','Contact mobile');
define('LBL_ADDLINE1','Address line1');
define('LBL_ADDLINE2','Address line2');
define('LBL_COUNTRY','Country');
define('LBL_STATE','State');
define('LBL_CITY','City');
define('LBL_ZIPCODE','Zipcode');
define('LBL_FAX','Fax');
define('LBL_WEBSITE','Website');

//Add and list Ticket
define('LBL_NAME','Tile');
define('LBL_TCK_DESC','Details');
define('LBL_PRIORITY','Priority');

define('LBL_STATUS','Status');
define('LBL_RESOLUTION','Resolution');
define('LBL_REPORTER','Reporter');
define('LBL_SEVERITY','Severity');
define('LBL_CREATED','Created On');
define('LBL_CLOSED','Closed On');
define('LBL_UPLOADS','Uploads');
define('LBL_PROJECT','Project');
define('LBL_MESSAGE','Note');
define('LBL_ASSIGNED','Assigned to');
define('LBL_TOTAL_LOGGED_WORK','Total work log');
define('LBL_ATTACHED_FILES','Attached Files');