<?php

define('LOGIN_EMAIL_VERIFICATION_INCOMPLETED','You should verify your email address before login.If you need those mail again please click on the belove link');
define('LOGIN_INACTIVE_USER','Only active client can login to system');
define('LOGIN_INCURRECT_DETAILS','Please enter a valid email address and password');

define('NEWCLIENT_EMAIL_SUBJECT','New client %CLIENT% added on Reowixmanager');
define('NEWCLIENT_EMAIL_MESSAGE1','Hi');
define('NEWCLIENT_EMAIL_MESSAGE2','Client with username %USERNAME% and password %PASSWORD% added on reowixmanager.Please login  on the address http://www.reowixmanager.com/tickets/client/login.php.');
define('NEWCLIENT_EMAIL_MESSAGE3','Thanks');
