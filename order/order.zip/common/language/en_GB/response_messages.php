<?php
define('ACTIVATION_EMAIL_SUBJECT','More faces , Activation mail');
define('ACTIVATION_EMAIL_MESSAGE1','Hi');
define('ACTIVATION_EMAIL_MESSAGE2','Thanks for registering with us.Please click on the following link to activate user account !');
define('ACTIVATION_EMAIL_MESSAGE3','Link');

define('EMAIL_VERIFICATION_MESSAGE1','Email verification completed');
define('EMAIL_VERIFICATION_MESSAGE2','Email verification already completed');
define('EMAIL_VERIFICATION_MESSAGE3','Invalid request');
define('EMAIL_VERIFICATION_MESSAGE4','Invalid code');


define('LOGIN_EMAIL_VERIFICATION_INCOMPLETED','You should verify your email address before login.If you need those mail again please click on the belove link');
define('LOGIN_INACTIVE_USER','Only active client can login to system');
define('LOGIN_INCURRECT_DETAILS','Please enter a valid email address and password');
