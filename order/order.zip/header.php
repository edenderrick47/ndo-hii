<?php

include("settings.php");

?>

<!DOCTYPE html>

<html lang="en-US">

<head>

    <meta charset="utf-8">

    <title>Order Now</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="description" content="">

    <meta name="keywords" content="">



    <!--[if lt IE 9]>

    <script src="https://html5shim.googlecode.com/svn/trunk/html5.js"></script>

    <![endif]-->



    <link rel="shortcut icon" href="img/favicon.ico">



    <!-- Core CSS -->

    <link type="text/css" rel="stylesheet" href="css/w3.css"><!-- Theme Core CSS -->

    <link type="text/css" rel="stylesheet" href="css/bootstrap.css"><!-- Bootstrap -->

    <link type="text/css" rel="stylesheet" href="font-awesome/css/font-awesome.min.css"><!-- font-awesome -->

    <link type="text/css" rel="stylesheet" href="css/style.css"><!-- Theme Core CSS -->



    <!-- Google Fonts here -->

    <link href='https://fonts.googleapis.com/css?family=Arvo:400,400italic,700,700italic' rel='stylesheet' type='text/css'>

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800' rel='stylesheet' type='text/css'>

</head>



<body>



    <!-- Preloader Area Start

    ====================================================== -->

    <div id="mask">

        <div id="loader">

        </div>

    </div>

    <!-- =================================================

    Preloader Area End -->



    <!-- Header Area Start

    ====================================================== -->


             <!--Top Area Start -->
    <div class='w3-container top' style="background: #1f1f1f">
        <a class='w3schools-logo' href='../index.html'>Home</span></a>
        <div class='w3-center toptext'><h1 style="color: #ffc8fc">PValueWriters Order Form</h1> </div></div>
          <!--   Top Area End -->





    <!-- =================================================

    Header Area End -->
