<div class="navbar-default sidebar" role="navigation">

                <div class="sidebar-nav navbar-collapse">

                    <ul class="nav" id="side-menu">

                        <!--<li class="sidebar-search">

                            <div class="input-group custom-search-form">

                                <input type="text" class="form-control" placeholder="Search...">

                                <span class="input-group-btn">

                                <button class="btn btn-default" type="button">

                                    <i class="fa fa-search"></i>

                                </button>

                            </span>

                            </div>

                        </li>-->

                        <li>

                            <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>

                        </li>

                        <!--CMS menu-->

                        <!--<li>

                            <a href="#"><i class="fa fa-newspaper-o"></i> CMS<span class="fa arrow"></span></a>

                            <ul class="nav nav-second-level">

                                <li>

                                    <a href="flot.html">Banner Area</a>

                                </li>

                                <li>

                                    <a href="morris.html">Page Title</a>

                                </li>

                            </ul>

                        </li>-->

                         <!--Category menu-->

                          <li>

                            <a href="#"><i class="fa fa-sitemap"></i> Category<span class="fa arrow"></span></a>

                            <ul class="nav nav-second-level">

                                <li>

                                    <a href="category.php">Add Category</a>

                                </li>

                                <li>

                                    <a href="categorylist.php">List</a>

                                    <a style="display:none;" href="categoryedit.php"></a>

                                </li>

                                

                                    

                              

                            </ul>

                        </li>

                         <!--Product menu-->

                          <li>

                            <a href="#"><i class="fa fa-briefcase"></i> Product <span class="fa arrow"></span></a>

                            <ul class="nav nav-second-level">

                                <li>

                                    <a href="product.php">Add Product</a>

                                </li>

                                <li>

                                    <a href="productlist.php">List</a>

                                     <a style="display:none;" href="productedit.php"></a>

                                </li>

                            </ul>

                        </li>

                         <!--Product option menu-->

                          <li>

                            <a href="#"><i class="fa fa-check-square-o"></i> Product Options <span class="fa arrow"></span></a>

                            <ul class="nav nav-second-level">

                                <li>

                                    <a href="option.php">Add option</a>

                                </li>

                                <li>

                                    <a href="optionlist.php">List</a>

                                     <a style="display:none;" href="optionedit.php"></a>

                                </li>

                            </ul>

                        </li>

                         <!--Coupons menu-->

                          <li>

                            <a href="#"><i class="fa fa-list-alt"></i> Coupons <span class="fa arrow"></span></a>

                            <ul class="nav nav-second-level">

                                <li>

                                    <a href="coupon.php">Add coupon</a>

                                </li>

                                <li>

                                    <a href="couponlist.php">List</a>

                                     <a style="display:none;" href="couponedit.php"></a>

                                </li>

                            </ul>

                        </li>

                          <!--Currency menu-->

                          <li>

                            <a href="#"><i class="fa fa-money"></i> Currency <span class="fa arrow"></span></a>

                            <ul class="nav nav-second-level">

                                <li>

                                    <a href="currency.php">Add Currency</a>

                                </li>

                                <li>

                                    <a href="currencylist.php">List</a>

                                    <a style="display:none;" href="currencyedit.php"></a>

                                </li>

                            </ul>

                        </li>

                         <li>

                            <a href="#"><i class="fa fa-envelope-o"></i> Mail Templates<span class="fa arrow"></span></a>

                             <ul class="nav nav-second-level">

                                <li>

                                    <a href="mailtemplate.php">Add Template</a>

                                </li>

                                <li>

                                    <a href="templatelist.php">List</a>

                                    <a style="display:none;" href="templateedit.php"></a>

                                </li>

                            </ul>

                        </li>

                         <li>

                            <a href="admin.php"><i class="fa fa-user"></i> Settings</a>

                        </li>

                         <li>

                            <a href="changepassword.php"><i class="fa fa-user"></i> Change Password</a>

                        </li>

                        <li>

                            <a href="orders.php"><i class="fa fa-sort-amount-asc"></i> Orders <span class="fa arrow"></span></a>
							 <ul class="nav nav-second-level">

                                <li>

                                    <a href="orders.php">All</a>

                                </li>

                                <li>

                                    <a href="orders.php?typ=mail">By Mail</a>

                                </li>
								 <li>

                                    <a href="orders.php?typ=paypal">By Paypal</a>

                                    <a style="display:none;" href="templateedit.php"></a>

                                </li>

                            </ul>
                        </li>

                         

                         



                            </ul>

                            <!-- /.nav-second-level -->

                        </li>

                    </ul>

                </div>

                <!-- /.sidebar-collapse -->

            </div>