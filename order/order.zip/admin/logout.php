<?php include('settings.php');
$adminObj->terminateLoggin();
header('location:login.php');
?>